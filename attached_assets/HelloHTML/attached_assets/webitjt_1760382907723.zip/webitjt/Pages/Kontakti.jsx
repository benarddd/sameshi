import React from "react";
import { MapPin, Phone, Mail, Clock, Send, MessageCircle } from "lucide-react";
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { motion } from "framer-motion";

// Fix for default marker icon
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

export default function Kontakti() {
  const emailAddress = "info@gjimnazi-keta.edu.al";
  const secretaryEmail = "sekretaria@gjimnazi-keta.edu.al";
  const phone1 = "+355 4 123 4567";
  const phone2 = "+355 69 123 4567";
  
  const schoolLocation = [41.333390, 19.865605];

  const handleEmailClick = (email) => {
    const subject = "Pyetje nga Website - Gjimnazi Abdulla Keta";
    const body = "Përshëndetje,%0D%0A%0D%0AUnë dëshiroj të pyes rreth:%0D%0A%0D%0A";
    window.location.href = `mailto:${email}?subject=${subject}&body=${body}`;
  };

  return (
    <div className="min-h-screen bg-[#071018] py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <motion.div
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ duration: 4, repeat: Infinity }}
            className="w-20 h-20 bg-gradient-to-br from-cyan-500/20 to-teal-500/20 rounded-2xl flex items-center justify-center mx-auto mb-6"
          >
            <MessageCircle className="w-10 h-10 text-cyan-400" />
          </motion.div>
          
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Na <span className="bg-gradient-to-r from-cyan-400 to-teal-400 bg-clip-text text-transparent">Kontaktoni</span>
          </h1>
          <p className="text-gray-400 text-lg">Jemi këtu për t'ju ndihmuar me çdo pyetje apo kërkesë</p>
        </motion.div>

        {/* Contact Cards Grid */}
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {/* Email Contact Card */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700/50 hover:border-cyan-500/30 transition-all duration-300"
          >
            <div className="flex items-center gap-4 mb-6">
              <motion.div
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.6 }}
                className="w-16 h-16 bg-gradient-to-br from-cyan-500/20 to-teal-500/20 rounded-xl flex items-center justify-center"
              >
                <Mail className="w-8 h-8 text-cyan-400" />
              </motion.div>
              <div>
                <h2 className="text-2xl font-bold text-white">Dërgo Email</h2>
                <p className="text-gray-400 text-sm">Kontakto me ne përmes email-it</p>
              </div>
            </div>

            <div className="space-y-4 mb-6">
              <div>
                <p className="text-sm text-gray-500 mb-1">Email Kryesor:</p>
                <a 
                  href={`mailto:${emailAddress}`}
                  className="text-cyan-400 hover:text-cyan-300 text-lg font-medium transition-colors flex items-center gap-2 group"
                >
                  <Mail className="w-4 h-4 group-hover:scale-110 transition-transform" />
                  {emailAddress}
                </a>
              </div>
              
              <div>
                <p className="text-sm text-gray-500 mb-1">Sekretaria:</p>
                <a 
                  href={`mailto:${secretaryEmail}`}
                  className="text-cyan-400 hover:text-cyan-300 text-lg font-medium transition-colors flex items-center gap-2 group"
                >
                  <Mail className="w-4 h-4 group-hover:scale-110 transition-transform" />
                  {secretaryEmail}
                </a>
              </div>
            </div>

            <div className="space-y-3">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => handleEmailClick(emailAddress)}
                className="w-full bg-gradient-to-r from-cyan-500 to-teal-600 hover:from-cyan-600 hover:to-teal-700 text-white py-3 px-6 rounded-xl font-semibold transition-all duration-300 flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/25"
              >
                <Send className="w-5 h-5" />
                Dërgo Email Tani
              </motion.button>
              
              <p className="text-xs text-gray-500 text-center">
                Do të hapet programi juaj i email-it
              </p>
            </div>
          </motion.div>

          {/* Phone & Address Card */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700/50"
          >
            <h2 className="text-2xl font-bold text-white mb-6">Informacion Kontakti</h2>
            
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Phone className="w-5 h-5 text-purple-400" />
                </div>
                <div>
                  <h3 className="text-white font-semibold mb-2">Telefon</h3>
                  <a 
                    href={`tel:${phone1.replace(/\s/g, '')}`}
                    className="text-gray-400 hover:text-cyan-400 transition-colors block mb-1"
                  >
                    {phone1}
                  </a>
                  <a 
                    href={`tel:${phone2.replace(/\s/g, '')}`}
                    className="text-gray-400 hover:text-cyan-400 transition-colors block"
                  >
                    {phone2}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-5 h-5 text-blue-400" />
                </div>
                <div>
                  <h3 className="text-white font-semibold mb-2">Adresa</h3>
                  <p className="text-gray-400">
                    Rruga "Abdulla Keta", Nr. 25<br />
                    Tiranë, Shqipëri 1001
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Clock className="w-5 h-5 text-green-400" />
                </div>
                <div>
                  <h3 className="text-white font-semibold mb-2">Orari i Punës</h3>
                  <p className="text-gray-400">
                    E Hënë - E Premte: 08:00 - 16:00<br />
                    E Shtunë: 09:00 - 13:00<br />
                    E Diel: Mbyllur
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Interactive Map */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-4 border border-gray-700/50 overflow-hidden"
        >
          <h2 className="text-2xl font-bold text-white mb-4 px-4">Lokacioni Ynë</h2>
          <div className="h-96 rounded-xl overflow-hidden">
            <MapContainer
              center={schoolLocation}
              zoom={16}
              scrollWheelZoom={false}
              className="w-full h-full"
              style={{ background: '#0f1823', zIndex: 0 }}
            >
              <TileLayer
                url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
              />
              <Marker position={schoolLocation}>
                <Popup>
                  <div className="text-center p-2">
                    <strong className="text-lg">Gjimnazi Abdulla Keta</strong>
                    <br />
                    <span className="text-sm text-gray-600">Rruga "Abdulla Keta", Tiranë</span>
                  </div>
                </Popup>
              </Marker>
            </MapContainer>
          </div>
        </motion.div>

        {/* Quick Tips */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-12 bg-gradient-to-r from-cyan-500/10 to-teal-500/10 border border-cyan-500/30 rounded-2xl p-8"
        >
          <h3 className="text-xl font-bold text-white mb-4 text-center">Këshilla për Kontakt më të Shpejtë</h3>
          <div className="grid md:grid-cols-3 gap-6 text-center">
            <div>
              <div className="text-3xl mb-2">📧</div>
              <h4 className="text-white font-semibold mb-1">Email</h4>
              <p className="text-gray-400 text-sm">Përgjigjemi brenda 24 orëve</p>
            </div>
            <div>
              <div className="text-3xl mb-2">📞</div>
              <h4 className="text-white font-semibold mb-1">Telefon</h4>
              <p className="text-gray-400 text-sm">Thirrni gjatë orarit të punës</p>
            </div>
            <div>
              <div className="text-3xl mb-2">🏫</div>
              <h4 className="text-white font-semibold mb-1">Në Person</h4>
              <p className="text-gray-400 text-sm">Vizitoni zyrën e sekretarisë</p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}