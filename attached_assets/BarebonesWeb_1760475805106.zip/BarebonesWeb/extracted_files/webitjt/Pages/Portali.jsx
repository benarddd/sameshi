import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Globe, LogIn, UserPlus } from "lucide-react";

export default function Portali() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    const authenticated = await base44.auth.isAuthenticated();
    setIsAuthenticated(authenticated);
    setIsLoading(false);
  };

  const handleLogin = () => {
    base44.auth.redirectToLogin(window.location.pathname);
  };

  const handleLogout = async () => {
    await base44.auth.logout();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#071018] flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-cyan-500/30 border-t-cyan-500 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-400">Duke ngarkuar...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#071018] flex items-center justify-center py-12 px-4">
        <div className="max-w-md w-full">
          <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-12 border border-gray-700/50 text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-cyan-500/20 to-teal-500/20 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Globe className="w-10 h-10 text-cyan-400" />
            </div>
            
            <h1 className="text-3xl font-bold text-white mb-4">
              Portali <span className="bg-gradient-to-r from-cyan-400 to-teal-400 bg-clip-text text-transparent">Shkollor</span>
            </h1>
            
            <p className="text-gray-400 mb-8">
              Aksesi në portalin shkollor kërkon identifikim. Ju lutem hyni në llogarinë tuaj për të vazhduar.
            </p>

            <Button
              onClick={handleLogin}
              className="w-full bg-gradient-to-r from-cyan-500 to-teal-600 hover:from-cyan-600 hover:to-teal-700 text-white py-6 text-lg font-semibold mb-4"
            >
              <LogIn className="w-5 h-5 mr-2" />
              Hyr në Portal
            </Button>

            <p className="text-sm text-gray-500">
              Nuk keni llogari? Kontaktoni administratën e shkollës.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#071018] py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-12">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">
              Portali <span className="bg-gradient-to-r from-cyan-400 to-teal-400 bg-clip-text text-transparent">Shkollor</span>
            </h1>
            <p className="text-gray-400">Mirë se erdhët në portalin tuaj</p>
          </div>
          <Button
            onClick={handleLogout}
            variant="outline"
            className="border-gray-700 text-gray-300 hover:bg-gray-800"
          >
            Dil nga Portali
          </Button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Portal sections would go here */}
          <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700/50 hover:border-cyan-500/30 transition-all duration-300">
            <h3 className="text-xl font-bold text-white mb-4">Notat</h3>
            <p className="text-gray-400 mb-4">Shiko notat dhe vlerësimet e tua</p>
            <Button className="w-full bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 border-cyan-500/30">
              Shiko Notat
            </Button>
          </div>

          <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700/50 hover:border-cyan-500/30 transition-all duration-300">
            <h3 className="text-xl font-bold text-white mb-4">Detyrat</h3>
            <p className="text-gray-400 mb-4">Menaxho detyrat dhe projektet</p>
            <Button className="w-full bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 border-cyan-500/30">
              Shiko Detyrat
            </Button>
          </div>

          <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700/50 hover:border-cyan-500/30 transition-all duration-300">
            <h3 className="text-xl font-bold text-white mb-4">Prezencat</h3>
            <p className="text-gray-400 mb-4">Kontrollo prezencat e tua</p>
            <Button className="w-full bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 border-cyan-500/30">
              Shiko Prezencat
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}