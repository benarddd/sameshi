import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Calendar, MapPin, Users, Trophy, Palette, Microscope, Code, Globe2, MessageSquare, Mail, User } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function ClubDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const id = parseInt(urlParams.get('id'));
  
  const clubs = [
    { 
      id: 1, 
      name: "Klubi i Futbollit", 
      description: "Trajnime dhe ndeshje të rregullta, pjesëmarrje në turne lokale dhe kombëtare", 
      fullDescription: "Klubi i Futbollit është një nga klubet më aktive të shkollës sonë. Ne organizojmë trajnime profesionale tri herë në javë, ku nxënësit mësojnë teknika të reja, përmirësojnë aftësitë e tyre dhe zhvillojnë punën në ekip.\n\nGjatë vitit shkollor, marrim pjesë në turne lokale dhe kombëtare, duke përfaqësuar shkollën tonë me krenari. Klubi ka fituar disa çmime të rëndësishme në vitet e fundit, duke treguar cilësinë e trajnimit dhe përkushtimin e anëtarëve tanë.\n\nÇdo nxënës që do të bashkohet me klubin do të ketë mundësinë të zhvillojë jo vetëm aftësitë sportive, por edhe disiplinën, punën në ekip dhe frymën konkurruese.", 
      category: "sports", 
      meeting_schedule: "E Hënë, E Mërkurë, E Premte 15:00-17:00", 
      location: "Fusha Sportive", 
      coordinator: "Prof. Alban Gashi", 
      coordinatorEmail: "a.gashi@gjimnazi-keta.edu.al",
      member_count: 25,
      achievements: [
        "Vendi i 1-rë në Turneun Kombëtar 2024",
        "Çmimi 'Ekipi më i Mirë' 2023",
        "5 anëtarë të përzgjedhur në ekipet kombëtare rinore"
      ],
      requirements: "Njohuri bazë të futbollit, dëshirë për të mësuar, angazhim dhe disiplinë"
    },
    { 
      id: 2, 
      name: "Klubi i Arteve", 
      description: "Pikturë, skulpturë dhe art digjital. Organizimi i ekspozitave dhe konkurseve artistike", 
      fullDescription: "Klubi i Arteve është një hapësirë ku kreativiteti lulëzon. Ne eksplorojmë forma të ndryshme artistike, nga piktura tradicionale deri tek arti digjital modern.\n\nGjatë vitit, organizojmë ekspozita të rregullta ku nxënësit shfaqin punët e tyre. Gjithashtu, marrim pjesë në konkurse kombëtare të arteve, ku anëtarët tanë kanë fituar çmime të shumta.\n\nNëse je i apasionuar pas artit dhe dëshiron të zhvillosh talentin tënd, ky është vendi i duhur për ty!", 
      category: "arts", 
      meeting_schedule: "E Martë, E Enjte 14:00-16:00", 
      location: "Salla e Arteve", 
      coordinator: "Prof. Mirela Shehu", 
      coordinatorEmail: "m.shehu@gjimnazi-keta.edu.al",
      member_count: 18,
      achievements: [
        "Vendi i 2-të në Konkursit Kombëtar të Arteve 2024",
        "3 ekspozita të suksesshme gjatë vitit",
        "Bashkëpunim me galeritë lokale"
      ],
      requirements: "Dashuri për artin, dëshirë për të eksperimentuar, kreativitet"
    },
    { 
      id: 3, 
      name: "Klubi i Shkencave", 
      description: "Eksperimente shkencore, projekte kërkimore dhe pjesëmarrje në panairin shkencor", 
      fullDescription: "Klubi i Shkencave ofron mundësi unike për nxënësit që duan të eksplorojnë botën e shkencës përtej teksteve shkollore. Ne kryejmë eksperimente të ndryshme në fizikë, kimi, biologji dhe më shumë.\n\nÇdo vit, anëtarët e klubit zhvillojnë projekte kërkimore origjinale dhe marrin pjesë në Panairin Shkencor Kombëtar. Disa nga projektet tona kanë fituar çmime të rëndësishme dhe kanë tërhequr vëmendjen e universiteteve.\n\nNëse je kurioz dhe dëshiron të zbulosh se si funksionon bota rreth nesh, bashkohu me ne!", 
      category: "science", 
      meeting_schedule: "E Mërkurë 15:00-17:00", 
      location: "Laboratori i Shkencave", 
      coordinator: "Prof. Elira Mara", 
      coordinatorEmail: "e.mara@gjimnazi-keta.edu.al",
      member_count: 22,
      achievements: [
        "Vendi i 1-rë në Panairin Shkencor 2024",
        "2 projekte të publikuara në revista shkencore",
        "Bashkëpunim me universitete lokale"
      ],
      requirements: "Kuriozitet shkencor, aftësi analitike, dëshirë për kërkim"
    },
    { 
      id: 4, 
      name: "Klubi i Teknologjisë", 
      description: "Programim, robotikë dhe zhvillim i projekteve teknologjike novatore", 
      fullDescription: "Klubi i Teknologjisë është në zemër të revolucionit digjital. Ne mësojmë programim, zhvillojmë aplikacione, ndërtojmë robotë dhe eksplorojmë teknologjitë më të fundit.\n\nAnëtarët e klubit punojnë në projekte të vërteta që zgjedhin probleme konkrete. Disa nga projektet tona janë zbatuar në shkollë dhe kanë marrë vëmendje nga kompani teknologjike.\n\nNëse dëshiron të mësosh të kodosh, të ndërtosh diçka me duart e tua, ose thjesht të jesh pjesë e së ardhmes, ky klub është për ty!", 
      category: "technology", 
      meeting_schedule: "E Premte 15:00-18:00", 
      location: "Laboratori i Kompjuterit", 
      coordinator: "Prof. Arben Hoxha", 
      coordinatorEmail: "a.hoxha@gjimnazi-keta.edu.al",
      member_count: 30,
      achievements: [
        "Fitues i Hackathon Kombëtar 2024",
        "3 aplikacione të zhvilluara dhe publikuara",
        "Partneritet me kompani teknologjike"
      ],
      requirements: "Interes për teknologjinë, aftësi bazë kompjuterike (jo të domosdoshme), kreativitet"
    },
  ];

  const club = clubs.find(c => c.id === id);

  if (!club) {
    return (
      <div className="min-h-screen bg-[#071018] py-12 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl text-white mb-4">Klubi nuk u gjet</h1>
          <Link to={createPageUrl("Klube")} className="text-cyan-400 hover:text-cyan-300">
            Kthehu te klubet
          </Link>
        </div>
      </div>
    );
  }

  const getCategoryIcon = (category) => {
    const icons = {
      sports: Trophy,
      arts: Palette,
      science: Microscope,
      technology: Code,
      cultural: Globe2,
      debate: MessageSquare,
    };
    const Icon = icons[category] || Users;
    return Icon;
  };

  const getCategoryColor = (category) => {
    const colors = {
      sports: "from-green-500/20 to-teal-500/20 border-green-500/30",
      arts: "from-purple-500/20 to-pink-500/20 border-purple-500/30",
      science: "from-blue-500/20 to-cyan-500/20 border-blue-500/30",
      technology: "from-orange-500/20 to-red-500/20 border-orange-500/30",
      cultural: "from-yellow-500/20 to-amber-500/20 border-yellow-500/30",
      debate: "from-indigo-500/20 to-purple-500/20 border-indigo-500/30",
    };
    return colors[category] || "from-gray-500/20 to-gray-600/20 border-gray-500/30";
  };

  const CategoryIcon = getCategoryIcon(club.category);

  return (
    <div className="min-h-screen bg-[#071018] py-12">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          {/* Back Button */}
          <Link
            to={createPageUrl("Klube")}
            className="inline-flex items-center gap-2 text-cyan-400 hover:text-cyan-300 mb-8 transition-colors group"
          >
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
            Kthehu te klubet
          </Link>

          {/* Club Header */}
          <div className={`bg-gradient-to-br ${getCategoryColor(club.category)} backdrop-blur-sm rounded-2xl p-8 md:p-12 border mb-8`}>
            <div className="flex items-start gap-6 mb-6">
              <motion.div
                whileHover={{ rotate: 360, scale: 1.1 }}
                transition={{ duration: 0.6 }}
                className="w-20 h-20 bg-cyan-500/20 rounded-2xl flex items-center justify-center flex-shrink-0"
              >
                <CategoryIcon className="w-10 h-10 text-cyan-400" />
              </motion.div>
              <div className="flex-1">
                <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
                  {club.name}
                </h1>
                <p className="text-gray-300 text-lg">
                  {club.description}
                </p>
              </div>
            </div>

            {/* Quick Info */}
            <div className="grid md:grid-cols-2 gap-4 mt-6">
              {club.meeting_schedule && (
                <div className="flex items-center gap-3 bg-gray-800/30 rounded-xl p-4">
                  <Calendar className="w-5 h-5 text-cyan-400 flex-shrink-0" />
                  <div>
                    <div className="text-xs text-gray-400 mb-1">Orari i Takimeve</div>
                    <div className="text-white font-medium">{club.meeting_schedule}</div>
                  </div>
                </div>
              )}
              {club.location && (
                <div className="flex items-center gap-3 bg-gray-800/30 rounded-xl p-4">
                  <MapPin className="w-5 h-5 text-cyan-400 flex-shrink-0" />
                  <div>
                    <div className="text-xs text-gray-400 mb-1">Vendndodhja</div>
                    <div className="text-white font-medium">{club.location}</div>
                  </div>
                </div>
              )}
              {club.member_count && (
                <div className="flex items-center gap-3 bg-gray-800/30 rounded-xl p-4">
                  <Users className="w-5 h-5 text-cyan-400 flex-shrink-0" />
                  <div>
                    <div className="text-xs text-gray-400 mb-1">Anëtarë Aktivë</div>
                    <div className="text-white font-medium">{club.member_count} nxënës</div>
                  </div>
                </div>
              )}
              {club.coordinator && (
                <div className="flex items-center gap-3 bg-gray-800/30 rounded-xl p-4">
                  <User className="w-5 h-5 text-cyan-400 flex-shrink-0" />
                  <div>
                    <div className="text-xs text-gray-400 mb-1">Koordinator</div>
                    <div className="text-white font-medium">{club.coordinator}</div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Full Description */}
          <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700/50 mb-8">
            <h2 className="text-2xl font-bold text-white mb-4">Rreth Klubit</h2>
            <div className="prose prose-invert max-w-none">
              {club.fullDescription.split('\n\n').map((paragraph, index) => (
                <p key={index} className="text-gray-300 leading-relaxed mb-4">
                  {paragraph}
                </p>
              ))}
            </div>
          </div>

          {/* Achievements */}
          {club.achievements && club.achievements.length > 0 && (
            <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700/50 mb-8">
              <h2 className="text-2xl font-bold text-white mb-6">Arritjet</h2>
              <div className="space-y-3">
                {club.achievements.map((achievement, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-start gap-3"
                  >
                    <div className="w-6 h-6 bg-cyan-500/20 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Trophy className="w-4 h-4 text-cyan-400" />
                    </div>
                    <p className="text-gray-300">{achievement}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {/* Requirements */}
          {club.requirements && (
            <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700/50 mb-8">
              <h2 className="text-2xl font-bold text-white mb-4">Kërkesat</h2>
              <p className="text-gray-300 leading-relaxed">{club.requirements}</p>
            </div>
          )}

          {/* Contact CTA */}
          <div className="bg-gradient-to-r from-cyan-500/10 to-teal-500/10 border border-cyan-500/30 rounded-2xl p-8 text-center">
            <h3 className="text-2xl font-bold text-white mb-3">
              Të Interesuar?
            </h3>
            <p className="text-gray-300 mb-6">
              Kontaktoni koordinatorin e klubit për më shumë informacion
            </p>
            <a
              href={`mailto:${club.coordinatorEmail}?subject=Interesim për ${club.name}`}
              className="inline-flex items-center gap-2 bg-gradient-to-r from-cyan-500 to-teal-600 hover:from-cyan-600 hover:to-teal-700 text-white px-8 py-3 rounded-xl font-semibold transition-all duration-300"
            >
              <Mail className="w-5 h-5" />
              Kontakto Koordinatorin
            </a>
          </div>
        </motion.div>
      </div>
    </div>
  );
}