import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Create page URLs for routing
export function createPageUrl(pageName: string): string {
  // Convert page name to URL format
  // e.g., "RrethNesh" -> "/rreth-nesh", "Ballina" -> "/ballina"
  const urlPath = pageName
    .replace(/([A-Z])/g, '-$1')
    .toLowerCase()
    .replace(/^-/, '');
  
  return `/${urlPath}`;
}
